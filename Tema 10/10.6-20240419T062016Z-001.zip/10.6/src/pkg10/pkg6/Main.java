/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package pkg10.pkg6;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.Scanner;

/**
 *
 * @author Usuario
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

        BufferedReader in = null;
        String linea = "";
        int numeros, cont = 0; 
        double media = 0;

        try {
            in = new BufferedReader(new FileReader("Enteros.txt"));
            linea = in.readLine();
            
        } catch (IOException ex) {
            System.out.println(ex.getMessage());
        }
        
        Scanner sc = new Scanner(in);
        while (sc.hasNextInt()) {
            numeros = sc.nextInt();
            System.out.println(numeros + " ");
            media += numeros;
            cont++;
        }
        System.out.println(linea);
        System.out.println("Media: " + media / cont);
        System.out.println("Cantidad: " + cont);
    }

}
